const size = [
  {
    title: "L",
    value: "L",
  },

  {
    title: "S",
    value: "S",
  },
  {
    title: "M",
    value: "M",
  },
  {
    title: "XL",
    value: "XL",
  },
];

export const color = [
  {
    title: "Red",
    value: "red",
  },
  {
    title: "Blue",
    value: "blue",
  },
  {
    title: "Yellow",
    value: "yellow",
  },
  {
    title: "White",
    value: "white",
  },
  {
    title: "Black",
    value: "black",
  },
];

export default size;
